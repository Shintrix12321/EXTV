import React from 'react';
import './assets/styles/global.css';
import Home from './pages/home';
function App() {
  return (
    <Home></Home>
  );
}

export default App;